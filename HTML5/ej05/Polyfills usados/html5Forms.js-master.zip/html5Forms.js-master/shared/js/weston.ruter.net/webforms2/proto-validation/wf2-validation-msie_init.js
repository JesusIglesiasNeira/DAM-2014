//Loaded dynamically in MSIE by script[defer] tag which emulated DOMContentLoaded event. See <http://dean.edwards.name/weblog/2005/09/busted/>
if(!window.ValidityState) 
	throw Error("Validation error: You must include the file 'wf2-validation.js' to enable the functionality. The file you included is loaded dynamically for MSIE.");
window.ValidityState.__initDescendents();